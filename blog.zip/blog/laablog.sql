-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 16, 2017 at 11:53 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `laablog`
--
CREATE DATABASE IF NOT EXISTS `laablog` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `laablog`;

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE IF NOT EXISTS `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE IF NOT EXISTS `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2017-10-16 10:28:27', '2017-10-16 10:28:27', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE IF NOT EXISTS `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE IF NOT EXISTS `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=157 ;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:8080/blog', 'yes'),
(2, 'home', 'http://localhost:8080/blog', 'yes'),
(3, 'blogname', 'Laablog', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'admin@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/index.php/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:89:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:57:"index.php/category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:52:"index.php/category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:33:"index.php/category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:45:"index.php/category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:27:"index.php/category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:54:"index.php/tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:49:"index.php/tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:30:"index.php/tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:42:"index.php/tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:24:"index.php/tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:55:"index.php/type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:50:"index.php/type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:31:"index.php/type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:43:"index.php/type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:25:"index.php/type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:42:"index.php/feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:37:"index.php/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:18:"index.php/embed/?$";s:21:"index.php?&embed=true";s:30:"index.php/page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:51:"index.php/comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:46:"index.php/comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:27:"index.php/comments/embed/?$";s:21:"index.php?&embed=true";s:54:"index.php/search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:49:"index.php/search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:30:"index.php/search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:42:"index.php/search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:24:"index.php/search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:57:"index.php/author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:52:"index.php/author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:33:"index.php/author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:45:"index.php/author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:27:"index.php/author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:79:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:74:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:55:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:67:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:49:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:66:"index.php/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:61:"index.php/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:42:"index.php/([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:54:"index.php/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:36:"index.php/([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:53:"index.php/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:48:"index.php/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:29:"index.php/([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:41:"index.php/([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:23:"index.php/([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:68:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:78:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:98:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:93:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:93:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:74:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:63:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:67:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:87:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:82:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:75:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:82:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:71:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:57:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:67:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:87:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:82:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:82:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:63:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:74:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:61:"index.php/([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:48:"index.php/([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:37:"index.php/.?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"index.php/.?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"index.php/.?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"index.php/.?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"index.php/.?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"index.php/.?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:26:"index.php/(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:30:"index.php/(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:50:"index.php/(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:45:"index.php/(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:38:"index.php/(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:45:"index.php/(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:34:"index.php/(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:0:{}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'sparkling.2.3.5/sparkling', 'yes'),
(41, 'stylesheet', 'sparkling.2.3.5/sparkling', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'posts', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '0', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:9:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";}s:13:"home-widget-1";a:0:{}s:13:"home-widget-2";a:0:{}s:13:"home-widget-3";a:0:{}s:15:"footer-widget-1";a:0:{}s:15:"footer-widget-2";a:0:{}s:15:"footer-widget-3";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'cron', 'a:4:{i:1508192912;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1508236134;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1508236499;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(109, 'theme_mods_twentyseventeen', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1508149763;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(113, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:7:"upgrade";s:8:"download";s:58:"http://downloads.wordpress.org/release/wordpress-4.8.2.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:58:"http://downloads.wordpress.org/release/wordpress-4.8.2.zip";s:10:"no_content";s:69:"http://downloads.wordpress.org/release/wordpress-4.8.2-no-content.zip";s:11:"new_bundled";s:70:"http://downloads.wordpress.org/release/wordpress-4.8.2-new-bundled.zip";s:7:"partial";s:68:"http://downloads.wordpress.org/release/wordpress-4.8.2-partial-1.zip";s:8:"rollback";b:0;}s:7:"current";s:5:"4.8.2";s:7:"version";s:5:"4.8.2";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:5:"4.8.1";}}s:12:"last_checked";i:1508149722;s:15:"version_checked";s:5:"4.8.1";s:12:"translations";a:0:{}}', 'no'),
(118, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1508149727;s:7:"checked";a:4:{s:25:"sparkling.2.3.5/sparkling";s:5:"2.3.5";s:13:"twentyfifteen";s:3:"1.8";s:15:"twentyseventeen";s:3:"1.3";s:13:"twentysixteen";s:3:"1.3";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'no'),
(119, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1508149726;s:8:"response";a:1:{s:19:"akismet/akismet.php";O:8:"stdClass":11:{s:2:"id";s:21:"w.org/plugins/akismet";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:3:"4.0";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:53:"http://downloads.wordpress.org/plugin/akismet.4.0.zip";s:5:"icons";a:3:{s:2:"1x";s:59:"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272";s:2:"2x";s:59:"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272";s:7:"default";s:59:"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272";}s:7:"banners";a:2:{s:2:"1x";s:61:"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904";s:7:"default";s:61:"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904";}s:11:"banners_rtl";a:0:{}s:6:"tested";s:5:"4.8.1";s:13:"compatibility";O:8:"stdClass":0:{}}}s:12:"translations";a:0:{}s:9:"no_update";a:1:{s:9:"hello.php";O:8:"stdClass":9:{s:2:"id";s:25:"w.org/plugins/hello-dolly";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:3:"1.6";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:57:"http://downloads.wordpress.org/plugin/hello-dolly.1.6.zip";s:5:"icons";a:3:{s:2:"1x";s:63:"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=969907";s:2:"2x";s:63:"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907";s:7:"default";s:63:"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907";}s:7:"banners";a:2:{s:2:"1x";s:65:"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342";s:7:"default";s:65:"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342";}s:11:"banners_rtl";a:0:{}}}}', 'no'),
(120, '_site_transient_timeout_browser_a8fa04da005937516d8bdfff00fdbe54', '1508754535', 'no'),
(121, '_site_transient_browser_a8fa04da005937516d8bdfff00fdbe54', 'a:10:{s:4:"name";s:6:"Chrome";s:7:"version";s:13:"61.0.3163.100";s:8:"platform";s:7:"Windows";s:10:"update_url";s:29:"https://www.google.com/chrome";s:7:"img_src";s:43:"http://s.w.org/images/browsers/chrome.png?1";s:11:"img_src_ssl";s:44:"https://s.w.org/images/browsers/chrome.png?1";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;s:6:"mobile";b:0;}', 'no'),
(123, '_transient_timeout_dash_v2_88ae138922fe95674369b1cb3d215a2b', '1508192946', 'no'),
(124, '_transient_dash_v2_88ae138922fe95674369b1cb3d215a2b', '<div class="rss-widget"><p><strong>RSS Error:</strong> WP HTTP Error: No working transports found</p></div><div class="rss-widget"><p><strong>RSS Error:</strong> WP HTTP Error: No working transports found</p></div>', 'no'),
(126, 'can_compress_scripts', '1', 'no'),
(127, 'current_theme', 'Sparkling', 'yes'),
(128, 'theme_mods_sparkling.2.3.5/sparkling', 'a:5:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:12:"header_image";s:76:"http://localhost:8080/blog/wp-content/uploads/2017/10/cropped-laa-logo-1.png";s:17:"header_image_data";O:8:"stdClass":5:{s:13:"attachment_id";i:5;s:3:"url";s:76:"http://localhost:8080/blog/wp-content/uploads/2017/10/cropped-laa-logo-1.png";s:13:"thumbnail_url";s:76:"http://localhost:8080/blog/wp-content/uploads/2017/10/cropped-laa-logo-1.png";s:6:"height";i:75;s:5:"width";i:155;}s:18:"nav_menu_locations";a:1:{s:7:"primary";i:2;}}', 'yes'),
(129, 'theme_switched', '', 'yes'),
(130, 'widget_sparkling-social', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(131, 'widget_sparkling_popular_posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(132, 'widget_sparkling-cats', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(141, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(150, '_site_transient_timeout_theme_roots', '1508156113', 'no'),
(151, '_site_transient_theme_roots', 'a:4:{s:25:"sparkling.2.3.5/sparkling";s:7:"/themes";s:13:"twentyfifteen";s:7:"/themes";s:15:"twentyseventeen";s:7:"/themes";s:13:"twentysixteen";s:7:"/themes";}', 'no'),
(152, '_transient_timeout_epsilon_plugin_information_transient_fancybox-for-wordpress', '1508156119', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(153, '_transient_epsilon_plugin_information_transient_fancybox-for-wordpress', 'O:8:"stdClass":18:{s:4:"name";s:22:"FancyBox for WordPress";s:4:"slug";s:22:"fancybox-for-wordpress";s:7:"version";s:6:"3.0.13";s:6:"author";s:44:"<a href="https://colorlib.com/">Colorlib</a>";s:14:"author_profile";s:37:"https://profiles.wordpress.org/moskis";s:12:"contributors";a:1:{s:8:"silkalns";s:39:"https://profiles.wordpress.org/silkalns";}s:12:"requires_php";b:0;s:7:"ratings";a:5:{i:5;i:33;i:4;i:3;i:3;i:1;i:2;i:1;i:1;i:7;}s:11:"num_ratings";i:45;s:15:"support_threads";i:2;s:24:"support_threads_resolved";i:0;s:8:"homepage";s:53:"https://wordpress.org/plugins/fancybox-for-wordpress/";s:8:"sections";a:5:{s:11:"description";s:2139:"<p>Seamlessly integrates FancyBox into your blog: Upload, activate, and you&#8217;re done. Additional configuration optional.</p>\n<p>You can easily customize almost anything you can think about fancybox lightbox: the border, margin width and color, zoom speed, animation type, close button position, overlay color and opacity and even more advanced option like several options to group images into galleries, and more&#8230;</p>\n<p>By default, the plugin will use jQuery to apply FancyBox to ANY thumbnails that link directly to an image. This includes posts, the sidebar, etc, so you can activate it and it will be applied automatically.</p>\n<h4>Demo</h4>\n<p>You can see the plugin working on a <a href="http://blog.moskis.net/2012/01/20/teclado-apple-en-windows-7/" rel="nofollow">this blog</a> although there&#8217;s nothing amazing to see, just a FancyBox simple implementation, that&#8217;s the point ? You can take a look at the code if you&#8217;re curious, though.</p>\n<h4>Further Reading</h4>\n<p>This plugin is developed and maintained by Colorlib. Which is well know for their free <a href="https://colorlib.com/wp/themes/" rel="nofollow"></a>WordPress themes. However, now they are looking to extend their presence in plugin development and believe that FancyBox lightbox is a great way to start.</p>\n<p>If you are new to WordPress and want to lear more we have got you covered. Colorlib will teach you have to <a href="https://colorlib.com/" rel="nofollow">start a blog</a> or <a href="https://colorlib.com/wp/how-to-make-a-website/" rel="nofollow">create a website</a> and much more. If you are already familiar with WordPress you likely want to learn how to make it faster and more reliable. That&#8217;s when you want to look into hosting and more specifically <a href="http://colorlib.com/wp/wordpress-hosting" rel="nofollow">WordPress hosting</a>.</p>\n<p>If you enjoy using FancyBox lightbox for WordPress please leave a <a href="https://wordpress.org/support/plugin/fancybox-for-wordpress/reviews/?filter=5" rel="nofollow">positive feedback</a>. We are committed to make it the best lightbox plugin for WordPress.</p>\n";s:12:"installation";s:455:"<ol>\n<li>Upload the <code>fancybox-for-wordpress</code> folder to the <code>/wp-content/plugins/</code> directory</li>\n<li>Activate the plugin through the &#8216;Plugins&#8217; menu in WordPress</li>\n<li>That&#8217;s it, FancyBox will be automatically applied to all your image links and galleries.</li>\n<li>If you want to customize a bit the look and feel of FancyBox, go to the Options Page under General Options in the WordPress Admin panel</li>\n</ol>\n";s:3:"faq";s:1580:"\n<h4>&#8211; There was a vulnerability detected in versions 3.0.2 and lower, is my site in danger?</h4>\n<p>\n<p>This vulnerability was patched in version 3.0.3.</p>\n<p>An additional change was introduced in version 3.0.4 to make sure that the malicious code can&#8217;t be printed to visitors even if it still remains in the database.</p>\n<p>If you think your site might still be using a vulnerable version of the plugin please log in to your WordPress admin panel, disable the plugin and clear any cache if your site uses a cache system.</p>\n<p>If you wish to continue using the plugin, check that the plugin is updated to the latest version from your admin panel and enable it. Then check the plugin&#8217;s settings page and make sure there&#8217;s no abnormal code in any of the fields, especially on the Extra Calls tab. If you are not sure about the code you see in the settings please use the Revert to Defaults button at the bottom of the settings page.</p>\n<p>If you think your site might be compromised in any other way check this guide: <a href="https://codex.wordpress.org/FAQ_My_site_was_hacked" rel="nofollow">WordPress Codex &#8211; FAQ My site was hacked</a>.</p>\n</p>\n<h4>&#8211; Is the FancyBox script vulnerable or unsafe?</h4>\n<p>\n<p>No, there&#8217;s nothing wrong with the actual FancyBox script that i know of.</p>\n<p>The vulnerability detected in versions 3.0.2 and lower of the &#8220;FancyBox for WordPress&#8221; plugin was limited to the plugin itself. Other FancyBox plugins or manual implementations of FancyBox are unrelated to this issue.</p>\n</p>\n\n";s:9:"changelog";s:10648:"<h4>3.0.12</h4>\n<p>Fixed errors causes by WordPress SVN.</p>\n<h4>3.0.7</h4>\n<ul>\n<li>Updated Fancybox library</li>\n<li>Updated other libraries this plugins depends on such as jQuery easing and jQuery Mousewheel</li>\n<li>Tested plugin with WordPress 4.6</li>\n</ul>\n<h4>3.0.6</h4>\n<ul>\n<li>Fixes to JavaScript code for showing and hiding elements as they are needed in Settings page. (Thanks to jono55 for reporting)</li>\n</ul>\n<h4>3.0.5</h4>\n<ul>\n<li>Fixed the Revert Options button.</li>\n<li>Fixed wrong version number being shown on the plugin&#8217;s settings page.</li>\n<li>Updated plugin and author links in readme and settings page.</li>\n<li>Updated localization catalog (POT file).</li>\n<li>Updated Spanish translation with minor updates.</li>\n<li>Updated Frequently Asked Questions in readme file.</li>\n<li>Removed version number from printed html source code.</li>\n<li>Removed outdated/incomplete translation binaries.</li>\n</ul>\n<h4>3.0.4</h4>\n<ul>\n<li>Renamed the setting affected by the security issue mentioned in 3.0.3. This should stop the malicious code from appearing on sites where the plugin is updated without removing the malicious code.</li>\n</ul>\n<h4>3.0.3</h4>\n<ul>\n<li>Fixed a security issue. (Thanks to mickaelb for reporting and Konstantin Kovshenin for providing the fix)</li>\n</ul>\n<h4>3.0.2</h4>\n<ul>\n<li>Added support for disabling fancybox on individual hyperlinked images by adding class=&#8217;nolightbox&#8217;. (Thanks to Artem Russakovskii)</li>\n<li>Added a link to the github project page in the info tab in the settings page.</li>\n<li>Fixed and cleaned the installation code, new installations of the plugin should work now without need to go to the settings page.</li>\n<li>Fixed false positives in filenames. (Thanks to Artem Russakovskii)</li>\n<li>Fixed incompatibility with wordpress installations where the wp-content directory had been renamed.</li>\n<li>Fixed an issue that could cause the version of the plugin to be removed from settings when deactivating the plugin.</li>\n<li>Improved HTTPS support by using better code to retrieve the plugin url and load files.</li>\n<li>Removed legacy code to suport upgrading settings from 2.x versions of the plugin. This was done to avoid possible issues with clean installations of the plugin.</li>\n<li>Updated some CSS rules in jQuery UI</li>\n<li>Some minor reformatting and cleanup of code (PHP comments, empty lines, )</li>\n</ul>\n<h4>3.0.1</h4>\n<ul>\n<li>Updated: Localization catalog updated.</li>\n<li>Updated: Spanish localization.</li>\n<li>Fixed: Minor change in settings page that may fix options page being invisible in some cases.</li>\n</ul>\n<h4>3.0.0</h4>\n<ul>\n<li>New: Fancybox v1.3.4 support This includes many new options, like title position.</li>\n<li>New: Additional FancyBox Calls option that lets the user write their own additional code to use FancyBox on specific areas of the blog, like email subscription buttons, login, etc.</li>\n<li>New: Revert settings button added to options page. When pressed, a confirmation dialog will appear.</li>\n<li>New: Improvements in options page, irrelevant settings (settings that depend on a disabled setting) will hide on real time, meaning a cleaner look in the options page.</li>\n<li>Updated: New cleaner code to select thumbnails on which to apply the fancbox script.</li>\n<li>Updated: Many parts of plugins rewriten with many improvements in code.</li>\n<li>Updated: Options are now serialized into a single row in the database.</li>\n<li>Fixed: Plugin should be SSL friendly from now on.</li>\n<li>Fixed: Do not call jQuery option in troubleshooting section didn&#8217;t work if easing was enabled.</li>\n<li>Fixed: Load at footer options should work better now.</li>\n<li>Fixed: CSS external files now addded with wp_enqueue_style().</li>\n<li>Fixed: has_cap error: User level value for options page removed, using role now instead. Thanks to <a href="https://wordpress.org/support/topic/plugin-fancybox-for-wordpress-has_cap-fix" rel="nofollow">vonkanehoffen</a>.</li>\n<li>Removed: jQuery &#8220;noConflict&#8221; Mode option removed bacause jQuery bundled with WordPress always used noConflict.</li>\n<li>Removed: Base64 data (&#8220;data:image/gif;base64,AAAA&#8221;) in left and right fancybox link&#8217;s backgrounds: It didn&#8217;t seem to be working and it is usually regarded as suspicious code, so it has been removed.</li>\n</ul>\n<h4>2.7.5</h4>\n<ul>\n<li>Fixed: Callback arguments are no longer added as &#8220;null&#8221; when they are not set in options page.</li>\n</ul>\n<h4>2.7.4</h4>\n<ul>\n<li>Fixed: Little error tagging 2.7.3, a file didn&#8217;t upload and broke options page.</li>\n<li>Update: Language POT file</li>\n</ul>\n<h4>2.7.3</h4>\n<ul>\n<li>Fixed: Settings not saving in some browsers. Thanks to <a href="https://wordpress.org/support/topic/plugin-fancybox-for-wordpress-save-changes-button-doesnt-submit-form?replies=7#post-1765041" rel="nofollow">supertomate</a></li>\n<li>Fixed: JS being added to other plugins&#8217; configuration pages. Thanks to <a href="https://wordpress.org/support/topic/plugin-fancybox-for-wordpress-theres-a-problem-with-is_plugin_page?replies=1#post-1888828" rel="nofollow">Brandon Dove</a></li>\n<li>Added: Support section in options page with better information</li>\n</ul>\n<h4>2.7.2</h4>\n<ul>\n<li>Fixed: Layout problem in options page in WordPress 2.9</li>\n</ul>\n<h4>2.7.1</h4>\n<ul>\n<li>Fixed: Z-index issue was left out in previus release</li>\n<li>Fixed: Setting to close fancybox when clicking on the overlay wasn&#8217;t available in the menu</li>\n<li>Fixed: Frame width and height options are now in the &#8220;Other&#8221; tab</li>\n<li>Fixed: Tabs now translated in Spanish localization</li>\n</ul>\n<h4>2.7.0</h4>\n<ul>\n<li>New: Fancybox v1.2.6 support</li>\n<li>New: New Admin page with tabs for better organization of all the options</li>\n<li>Added: Setting to change the speed of the animation when changing gallery items</li>\n<li>Added: Setting to enable or disable Escape key to close Fancybox</li>\n<li>Added: Setting to show or hide close button</li>\n<li>Added: Setting to close fancybox when clicking on the overlay</li>\n<li>Added: Setting to enable or disable callback function on start, show and close events</li>\n<li>Added: Italian translation</li>\n<li>Added: Russian translation</li>\n<li>Added: &#8220;Load JS at Footer&#8221; option</li>\n<li>Added: New Changelog tab in  WordPress Plugin Directory</li>\n<li>Fixed: Some typos in Spanish translation</li>\n<li>Fixed: FancyBox not showing above some elements (those with zindex higher than 90)</li>\n<li>Fixed: JavaScript code being included in all admin pages instead of just the plugin&#8217;s options page.</li>\n<li>Fixed: noClonflict preventing frames to work in Fancybox</li>\n<li>Fixed: Custom frame width and height not being applied</li>\n<li>Updated: Japanese translation</li>\n<li>Updated: JS is now Minified instead of Packed</li>\n</ul>\n<h4>2.6.0</h4>\n<ul>\n<li>Optimized the JavaScript code used to apply FancyBox</li>\n<li>Updated Custom Expression section in Options Page</li>\n<li>Fixed uppercase image extensions not being recognized</li>\n<li>CSS is now loaded before the JavaScript for better parallelization</li>\n<li>jquery.easing.1.3.js compressed (from 8,10kb to 3,47kb) and renamed to jquery.easing.1.3.pack.js</li>\n<li>Added Turkish translation (some strings missing)</li>\n<li>Added Japanese translation (some strings missing)</li>\n<li>Updated Spanish translation</li>\n<li>Updated to use new Plugin API in WP2.7 for better forward compatibility</li>\n<li>Removed /wp-content/ reference in fancybox.php for better WP2.8 support</li>\n<li>Optimized some code readability</li>\n</ul>\n<h4>2.5.1</h4>\n<ul>\n<li>Fixed the plugin not working when selecting Gallery Type &#8220;By Post&#8221;</li>\n<li>Fixed a bug that would prevent the title in the IMG tag from being copied to the A tag in some cases</li>\n<li>Fixed the Custom Expression showing in the Admin panel when other gallery types are selected</li>\n</ul>\n<h4>2.5</h4>\n<ul>\n<li>Support for localizations (Spanish and German localizations included)</li>\n<li>Some parts of the code completely rewritten</li>\n<li>Fixed fancybox files being loaded on the admin pages</li>\n<li>New options for close button position, custom jquery expressions, iframe content</li>\n<li>Options page mostly rewritten, better organized</li>\n<li>Medium/advanced, troubleshooting/uninstall options collapsable, hidden by default</li>\n<li>Better support guidelines and links on options page</li>\n<li>Settings link on the Manage plugins page</li>\n<li>Custom expression hidden when not used</li>\n<li>Title atribute on IMG tags is now copied to its parent A tag for better caption support</li>\n<li>New uninstall options and better handling of new options when installing/updating</li>\n<li>Cleans any old options no longer needed when plugin is activated/updated</li>\n</ul>\n<h4>2.2</h4>\n<ul>\n<li>Updated to FancyBox 1.2.1</li>\n<li>Added new settings to Options Page: Easing, padding size, border color</li>\n<li>Tweaked CSS to prevent some themes from adding unwanted styles to fancybox (especially background colors and link outlines)</li>\n<li>Options Page reorganized in three sections: Appearance, Behaviour and Troubleshooting Settings, to make settings easier to find</li>\n</ul>\n<h4>2.1.1</h4>\n<ul>\n<li>Fixed a new bug introduced in 2.1 that prevented options from being saved. Sorry about the mess ?</li>\n</ul>\n<h4>2.1</h4>\n<ul>\n<li>Fixed a major bug in 2.0 that prevented it from working until plugin&#8217;s options page was visited</li>\n<li>Added two options for troubleshooting that might help in some cases if the plugin doesn&#8217;t work: disable jQuery noConflict and skip jQuery call</li>\n<li>Additional fixes to caption CSS: Captions should look better now in Hybrid theme, child themes, and other situations where general table elements are improperly styled</li>\n</ul>\n<h4>2.0</h4>\n<ul>\n<li>Brand new Options Page in Admin Panel lets you easely customize many options: fancybox auto apply, image resize to fit, opacity fade while zooming, zoom speed, overlay on/off, overlay color, overlay opacity, close fancybox on image click, keep fancybox centered while scrolling</li>\n<li>CSS completely updated for FancyBox 1.2.0</li>\n<li>Captions fixed in IE</li>\n</ul>\n<h4>1.3</h4>\n<ul>\n<li>Shadows and Close button should be fixed now</li>\n</ul>\n<h4>1.2</h4>\n<ul>\n<li>Updated to FancyBox 1.2.0</li>\n<li>Uses packed version of the JavaScript file (8kb instead of 14kb)</li>\n</ul>\n<h4>1.1</h4>\n<ul>\n<li>Fixed FancyBox not being applied to .jpeg files</li>\n<li>Fixed &#8220;Click to close&#8221; overlay text</li>\n<li>Moved images to /img/ folder</li>\n</ul>\n";s:11:"screenshots";s:907:"<ol><li><a href="https://ps.w.org/fancybox-for-wordpress/trunk/screenshot-1.png?rev=1590175"><img src="https://ps.w.org/fancybox-for-wordpress/trunk/screenshot-1.png?rev=1590175" alt="Simple example of fancybox on a post. &lt;a href=&quot;http://blog.moskis.net/2012/01/20/teclado-apple-en-windows-7/&quot;&gt;Live demo here&lt;/a&gt;"></a><p>Simple example of fancybox on a post. <a href="http://blog.moskis.net/2012/01/20/teclado-apple-en-windows-7/">Live demo here</a></p></li><li><a href="https://ps.w.org/fancybox-for-wordpress/trunk/screenshot-2.png?rev=1590175"><img src="https://ps.w.org/fancybox-for-wordpress/trunk/screenshot-2.png?rev=1590175" alt="Basic settings on Options Page in the Admin Panel. This makes it very easy to customize the plugin to your needs"></a><p>Basic settings on Options Page in the Admin Panel. This makes it very easy to customize the plugin to your needs</p></li></ol>";}s:17:"short_description";s:121:"Seamlessly integrates FancyBox into your blog: Upload, activate, and you&#039;re done. Additional configuration optional.";s:13:"download_link";s:65:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.zip";s:11:"screenshots";a:2:{i:1;a:2:{s:3:"src";s:74:"https://ps.w.org/fancybox-for-wordpress/trunk/screenshot-1.png?rev=1590175";s:7:"caption";s:128:"Simple example of fancybox on a post. <a href="http://blog.moskis.net/2012/01/20/teclado-apple-en-windows-7/">Live demo here</a>";}i:2;a:2:{s:3:"src";s:74:"https://ps.w.org/fancybox-for-wordpress/trunk/screenshot-2.png?rev=1590175";s:7:"caption";s:112:"Basic settings on Options Page in the Admin Panel. This makes it very easy to customize the plugin to your needs";}}s:8:"versions";a:29:{s:3:"1.0";s:69:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.1.0.zip";s:5:"1.0.2";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.1.0.2.zip";s:3:"1.1";s:69:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.1.1.zip";s:3:"1.2";s:69:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.1.2.zip";s:3:"1.3";s:69:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.1.3.zip";s:3:"2.0";s:69:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.2.0.zip";s:3:"2.1";s:69:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.2.1.zip";s:5:"2.1.1";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.2.1.1.zip";s:3:"2.2";s:69:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.2.2.zip";s:3:"2.5";s:69:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.2.5.zip";s:5:"2.5.1";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.2.5.1.zip";s:5:"2.6.0";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.2.6.0.zip";s:5:"2.7.0";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.2.7.0.zip";s:5:"2.7.1";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.2.7.1.zip";s:5:"2.7.2";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.2.7.2.zip";s:5:"2.7.3";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.2.7.3.zip";s:5:"2.7.4";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.2.7.4.zip";s:5:"2.7.5";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.2.7.5.zip";s:5:"3.0.0";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.3.0.0.zip";s:5:"3.0.1";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.3.0.1.zip";s:6:"3.0.10";s:72:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.3.0.10.zip";s:5:"3.0.2";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.3.0.2.zip";s:5:"3.0.3";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.3.0.3.zip";s:5:"3.0.4";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.3.0.4.zip";s:5:"3.0.5";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.3.0.5.zip";s:5:"3.0.6";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.3.0.6.zip";s:5:"3.0.7";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.3.0.7.zip";s:5:"3.0.8";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.3.0.8.zip";s:5:"3.0.9";s:71:"https://downloads.wordpress.org/plugin/fancybox-for-wordpress.3.0.9.zip";}s:5:"icons";a:1:{s:7:"default";s:7150:"data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjAiIGhlaWdodD0iMTIwIiB2aWV3Ym94PSIwIDAgMTIwIDEyMCIgcHJlc2VydmVBc3BlY3RSYXRpbz0ibm9uZSI+PHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0icmdiKDE1NCwgMTQwLCAxMjYpIiAvPjxjaXJjbGUgY3g9IjAiIGN5PSIwIiByPSIxNy41IiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMDQ2O3N0cm9rZS13aWR0aDo1cHg7IiAvPjxjaXJjbGUgY3g9IjEyMCIgY3k9IjAiIHI9IjE3LjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzIyMiIgc3R5bGU9Im9wYWNpdHk6MC4wNDY7c3Ryb2tlLXdpZHRoOjVweDsiIC8+PGNpcmNsZSBjeD0iMCIgY3k9IjEyMCIgcj0iMTcuNSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjA0NjtzdHJva2Utd2lkdGg6NXB4OyIgLz48Y2lyY2xlIGN4PSIxMjAiIGN5PSIxMjAiIHI9IjE3LjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzIyMiIgc3R5bGU9Im9wYWNpdHk6MC4wNDY7c3Ryb2tlLXdpZHRoOjVweDsiIC8+PGNpcmNsZSBjeD0iMjAiIGN5PSIwIiByPSIxNy41IiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMDcyO3N0cm9rZS13aWR0aDo1cHg7IiAvPjxjaXJjbGUgY3g9IjIwIiBjeT0iMTIwIiByPSIxNy41IiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMDcyO3N0cm9rZS13aWR0aDo1cHg7IiAvPjxjaXJjbGUgY3g9IjQwIiBjeT0iMCIgcj0iMTcuNSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjE1O3N0cm9rZS13aWR0aDo1cHg7IiAvPjxjaXJjbGUgY3g9IjQwIiBjeT0iMTIwIiByPSIxNy41IiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMTU7c3Ryb2tlLXdpZHRoOjVweDsiIC8+PGNpcmNsZSBjeD0iNjAiIGN5PSIwIiByPSIxNy41IiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMTQxMzMzMzMzMzMzMzM7c3Ryb2tlLXdpZHRoOjVweDsiIC8+PGNpcmNsZSBjeD0iNjAiIGN5PSIxMjAiIHI9IjE3LjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2RkZCIgc3R5bGU9Im9wYWNpdHk6MC4xNDEzMzMzMzMzMzMzMztzdHJva2Utd2lkdGg6NXB4OyIgLz48Y2lyY2xlIGN4PSI4MCIgY3k9IjAiIHI9IjE3LjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzIyMiIgc3R5bGU9Im9wYWNpdHk6MC4wMjg2NjY2NjY2NjY2Njc7c3Ryb2tlLXdpZHRoOjVweDsiIC8+PGNpcmNsZSBjeD0iODAiIGN5PSIxMjAiIHI9IjE3LjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzIyMiIgc3R5bGU9Im9wYWNpdHk6MC4wMjg2NjY2NjY2NjY2Njc7c3Ryb2tlLXdpZHRoOjVweDsiIC8+PGNpcmNsZSBjeD0iMTAwIiBjeT0iMCIgcj0iMTcuNSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZGRkIiBzdHlsZT0ib3BhY2l0eTowLjA3MjtzdHJva2Utd2lkdGg6NXB4OyIgLz48Y2lyY2xlIGN4PSIxMDAiIGN5PSIxMjAiIHI9IjE3LjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2RkZCIgc3R5bGU9Im9wYWNpdHk6MC4wNzI7c3Ryb2tlLXdpZHRoOjVweDsiIC8+PGNpcmNsZSBjeD0iMCIgY3k9IjIwIiByPSIxNy41IiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMDcyO3N0cm9rZS13aWR0aDo1cHg7IiAvPjxjaXJjbGUgY3g9IjEyMCIgY3k9IjIwIiByPSIxNy41IiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMDcyO3N0cm9rZS13aWR0aDo1cHg7IiAvPjxjaXJjbGUgY3g9IjIwIiBjeT0iMjAiIHI9IjE3LjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2RkZCIgc3R5bGU9Im9wYWNpdHk6MC4xMDY2NjY2NjY2NjY2NztzdHJva2Utd2lkdGg6NXB4OyIgLz48Y2lyY2xlIGN4PSI0MCIgY3k9IjIwIiByPSIxNy41IiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMDI4NjY2NjY2NjY2NjY3O3N0cm9rZS13aWR0aDo1cHg7IiAvPjxjaXJjbGUgY3g9IjYwIiBjeT0iMjAiIHI9IjE3LjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2RkZCIgc3R5bGU9Im9wYWNpdHk6MC4xMjQ7c3Ryb2tlLXdpZHRoOjVweDsiIC8+PGNpcmNsZSBjeD0iODAiIGN5PSIyMCIgcj0iMTcuNSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjA5ODtzdHJva2Utd2lkdGg6NXB4OyIgLz48Y2lyY2xlIGN4PSIxMDAiIGN5PSIyMCIgcj0iMTcuNSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZGRkIiBzdHlsZT0ib3BhY2l0eTowLjEyNDtzdHJva2Utd2lkdGg6NXB4OyIgLz48Y2lyY2xlIGN4PSIwIiBjeT0iNDAiIHI9IjE3LjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2RkZCIgc3R5bGU9Im9wYWNpdHk6MC4xMjQ7c3Ryb2tlLXdpZHRoOjVweDsiIC8+PGNpcmNsZSBjeD0iMTIwIiBjeT0iNDAiIHI9IjE3LjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2RkZCIgc3R5bGU9Im9wYWNpdHk6MC4xMjQ7c3Ryb2tlLXdpZHRoOjVweDsiIC8+PGNpcmNsZSBjeD0iMjAiIGN5PSI0MCIgcj0iMTcuNSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZGRkIiBzdHlsZT0ib3BhY2l0eTowLjEyNDtzdHJva2Utd2lkdGg6NXB4OyIgLz48Y2lyY2xlIGN4PSI0MCIgY3k9IjQwIiByPSIxNy41IiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMDk4O3N0cm9rZS13aWR0aDo1cHg7IiAvPjxjaXJjbGUgY3g9IjYwIiBjeT0iNDAiIHI9IjE3LjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzIyMiIgc3R5bGU9Im9wYWNpdHk6MC4wNDY7c3Ryb2tlLXdpZHRoOjVweDsiIC8+PGNpcmNsZSBjeD0iODAiIGN5PSI0MCIgcj0iMTcuNSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjE1O3N0cm9rZS13aWR0aDo1cHg7IiAvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjQwIiByPSIxNy41IiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMTU7c3Ryb2tlLXdpZHRoOjVweDsiIC8+PGNpcmNsZSBjeD0iMCIgY3k9IjYwIiByPSIxNy41IiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMDI7c3Ryb2tlLXdpZHRoOjVweDsiIC8+PGNpcmNsZSBjeD0iMTIwIiBjeT0iNjAiIHI9IjE3LjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2RkZCIgc3R5bGU9Im9wYWNpdHk6MC4wMjtzdHJva2Utd2lkdGg6NXB4OyIgLz48Y2lyY2xlIGN4PSIyMCIgY3k9IjYwIiByPSIxNy41IiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMTA2NjY2NjY2NjY2Njc7c3Ryb2tlLXdpZHRoOjVweDsiIC8+PGNpcmNsZSBjeD0iNDAiIGN5PSI2MCIgcj0iMTcuNSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZGRkIiBzdHlsZT0ib3BhY2l0eTowLjA3MjtzdHJva2Utd2lkdGg6NXB4OyIgLz48Y2lyY2xlIGN4PSI2MCIgY3k9IjYwIiByPSIxNy41IiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMDU0NjY2NjY2NjY2NjY3O3N0cm9rZS13aWR0aDo1cHg7IiAvPjxjaXJjbGUgY3g9IjgwIiBjeT0iNjAiIHI9IjE3LjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2RkZCIgc3R5bGU9Im9wYWNpdHk6MC4xMDY2NjY2NjY2NjY2NztzdHJva2Utd2lkdGg6NXB4OyIgLz48Y2lyY2xlIGN4PSIxMDAiIGN5PSI2MCIgcj0iMTcuNSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZGRkIiBzdHlsZT0ib3BhY2l0eTowLjE0MTMzMzMzMzMzMzMzO3N0cm9rZS13aWR0aDo1cHg7IiAvPjxjaXJjbGUgY3g9IjAiIGN5PSI4MCIgcj0iMTcuNSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZGRkIiBzdHlsZT0ib3BhY2l0eTowLjAzNzMzMzMzMzMzMzMzMztzdHJva2Utd2lkdGg6NXB4OyIgLz48Y2lyY2xlIGN4PSIxMjAiIGN5PSI4MCIgcj0iMTcuNSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZGRkIiBzdHlsZT0ib3BhY2l0eTowLjAzNzMzMzMzMzMzMzMzMztzdHJva2Utd2lkdGg6NXB4OyIgLz48Y2lyY2xlIGN4PSIyMCIgY3k9IjgwIiByPSIxNy41IiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMTI0O3N0cm9rZS13aWR0aDo1cHg7IiAvPjxjaXJjbGUgY3g9IjQwIiBjeT0iODAiIHI9IjE3LjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzIyMiIgc3R5bGU9Im9wYWNpdHk6MC4xMzI2NjY2NjY2NjY2NztzdHJva2Utd2lkdGg6NXB4OyIgLz48Y2lyY2xlIGN4PSI2MCIgY3k9IjgwIiByPSIxNy41IiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMTU7c3Ryb2tlLXdpZHRoOjVweDsiIC8+PGNpcmNsZSBjeD0iODAiIGN5PSI4MCIgcj0iMTcuNSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZGRkIiBzdHlsZT0ib3BhY2l0eTowLjE0MTMzMzMzMzMzMzMzO3N0cm9rZS13aWR0aDo1cHg7IiAvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSIxNy41IiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMTI0O3N0cm9rZS13aWR0aDo1cHg7IiAvPjxjaXJjbGUgY3g9IjAiIGN5PSIxMDAiIHI9IjE3LjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2RkZCIgc3R5bGU9Im9wYWNpdHk6MC4wMjtzdHJva2Utd2lkdGg6NXB4OyIgLz48Y2lyY2xlIGN4PSIxMjAiIGN5PSIxMDAiIHI9IjE3LjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2RkZCIgc3R5bGU9Im9wYWNpdHk6MC4wMjtzdHJva2Utd2lkdGg6NXB4OyIgLz48Y2lyY2xlIGN4PSIyMCIgY3k9IjEwMCIgcj0iMTcuNSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjAyODY2NjY2NjY2NjY2NztzdHJva2Utd2lkdGg6NXB4OyIgLz48Y2lyY2xlIGN4PSI0MCIgY3k9IjEwMCIgcj0iMTcuNSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjExNTMzMzMzMzMzMzMzO3N0cm9rZS13aWR0aDo1cHg7IiAvPjxjaXJjbGUgY3g9IjYwIiBjeT0iMTAwIiByPSIxNy41IiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMDcyO3N0cm9rZS13aWR0aDo1cHg7IiAvPjxjaXJjbGUgY3g9IjgwIiBjeT0iMTAwIiByPSIxNy41IiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMDgwNjY2NjY2NjY2NjY3O3N0cm9rZS13aWR0aDo1cHg7IiAvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjEwMCIgcj0iMTcuNSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjA5ODtzdHJva2Utd2lkdGg6NXB4OyIgLz48L3N2Zz4=";}}', 'no'),
(154, '_transient_timeout_epsilon_plugin_information_transient_simple-custom-post-order', '1508156120', 'no'),
(155, '_transient_epsilon_plugin_information_transient_simple-custom-post-order', 'O:8:"stdClass":18:{s:4:"name";s:24:"Simple Custom Post Order";s:4:"slug";s:24:"simple-custom-post-order";s:7:"version";s:5:"2.3.2";s:6:"author";s:47:"<a href="https://colorlib.com/wp/">Colorlib</a>";s:14:"author_profile";s:39:"https://profiles.wordpress.org/hsameerc";s:12:"contributors";a:2:{s:15:"colorlibplugins";s:46:"https://profiles.wordpress.org/colorlibplugins";s:8:"silkalns";s:39:"https://profiles.wordpress.org/silkalns";}s:12:"requires_php";b:0;s:7:"ratings";a:5:{i:5;i:93;i:4;i:2;i:3;i:4;i:2;i:2;i:1;i:11;}s:11:"num_ratings";i:112;s:15:"support_threads";i:3;s:24:"support_threads_resolved";i:0;s:8:"homepage";s:58:"https://wordpress.org/plugins-wp/simple-custom-post-order/";s:8:"sections";a:5:{s:11:"description";s:416:"<p>Order posts(posts, any custom post types) using a Drag and Drop Sortable JavaScript. Configuration is unnecessary. You can do directly on default WordPress administration.<br />\nExcluding custom query which uses order or orderby parameters, in get_posts or query_posts and so on.</p>\n<p>This plugins is now supported and maintained by <a href="//colorlib.com/wp/“" rel="“friend” nofollow">Colorlib</a>.</p>\n";s:12:"installation";s:188:"<ol>\n<li>Upload <code>plugin-name.php</code> to the <code>/wp-content/plugins/</code> directory</li>\n<li>Activate the plugin through the &#8216;Plugins&#8217; menu in WordPress</li>\n</ol>\n";s:3:"faq";s:90:"\n<h4>A question that someone might have</h4>\n<p>\n<p>An answer to that question.</p>\n</p>\n\n";s:9:"changelog";s:1137:"<h4>Version 1.0 (20-07-2013)</h4>\n<ul>\n<li>Initial release.</li>\n</ul>\n<h4>Version 1.5 (25-07-2013)</h4>\n<ul>\n<li>Fix : fix errors</li>\n<li>Added Taxonomy Sort</li>\n<li>Added Taxonomy Sort option In setting Page</li>\n</ul>\n<h4>Version 2.0 (22-11-2013)</h4>\n<ul>\n<li>Fixed Undefined Notice Error in wp version 3.7.1</li>\n<li>Taxonomy Activate Checkbox removed.</li>\n</ul>\n<h4>Version 2.1 (31-12-2013)</h4>\n<ul>\n<li>Prevent Breaking autocomplete </li>\n</ul>\n<h4>Version 2.2 (02-07-2014)</h4>\n<ul>\n<li>Fixed bug: Custom Query which uses &#8216;order&#8217; or &#8216;orderby&#8217; parameters is preferred</li>\n<li>It does not depend on the designation manner of arguments( Parameters ). ( $args = &#8216;orderby=&amp;order=&#8217; or $args = array( &#8216;orderby&#8217; =&gt; &#8221;, &#8216;order&#8217; =&gt; &#8221; ) )</li>\n<li>Previous Versions Issues were Improved.</li>\n<li>Removed Taxonomy Sort( Will add in next Version ? )</li>\n</ul>\n<h4>Version 2.3 (24-03-2014)</h4>\n<ul>\n<li>Fixed major bug on taxonomy and post order</li>\n</ul>\n<h4>Version 2.3.2 (17-03-2017)</h4>\n<ul>\n<li>Minor documentation and readme tweaks</li>\n</ul>\n";s:11:"screenshots";s:656:"<ol><li><a href="https://ps.w.org/simple-custom-post-order/trunk/screenshot-3.png?rev=1616546"><img src="https://ps.w.org/simple-custom-post-order/trunk/screenshot-3.png?rev=1616546" alt=""></a></li><li><a href="https://ps.w.org/simple-custom-post-order/trunk/screenshot-1.png?rev=1616546"><img src="https://ps.w.org/simple-custom-post-order/trunk/screenshot-1.png?rev=1616546" alt="screenshot-1"></a><p>screenshot-1</p></li><li><a href="https://ps.w.org/simple-custom-post-order/trunk/screenshot-2.png?rev=1616546"><img src="https://ps.w.org/simple-custom-post-order/trunk/screenshot-2.png?rev=1616546" alt="screenshot-2"></a><p>screenshot-2</p></li></ol>";}s:17:"short_description";s:114:"Order posts(posts, any custom post types) using a Drag and Drop Sortable JavaScript. Configuration is unnecessary.";s:13:"download_link";s:67:"https://downloads.wordpress.org/plugin/simple-custom-post-order.zip";s:11:"screenshots";a:3:{i:3;a:2:{s:3:"src";s:76:"https://ps.w.org/simple-custom-post-order/trunk/screenshot-3.png?rev=1616546";s:7:"caption";s:0:"";}i:1;a:2:{s:3:"src";s:76:"https://ps.w.org/simple-custom-post-order/trunk/screenshot-1.png?rev=1616546";s:7:"caption";s:12:"screenshot-1";}i:2;a:2:{s:3:"src";s:76:"https://ps.w.org/simple-custom-post-order/trunk/screenshot-2.png?rev=1616546";s:7:"caption";s:12:"screenshot-2";}}s:8:"versions";a:5:{s:3:"1.0";s:71:"https://downloads.wordpress.org/plugin/simple-custom-post-order.1.0.zip";s:3:"1.5";s:71:"https://downloads.wordpress.org/plugin/simple-custom-post-order.1.5.zip";s:3:"2.0";s:71:"https://downloads.wordpress.org/plugin/simple-custom-post-order.2.0.zip";s:3:"2.1";s:71:"https://downloads.wordpress.org/plugin/simple-custom-post-order.2.1.zip";s:3:"2.2";s:71:"https://downloads.wordpress.org/plugin/simple-custom-post-order.2.2.zip";}s:5:"icons";a:1:{s:7:"default";s:17742:"data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMjAiIGhlaWdodD0iNTQwIiB2aWV3Ym94PSIwIDAgMjIwIDU0MCIgcHJlc2VydmVBc3BlY3RSYXRpbz0ibm9uZSI+PHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0icmdiKDE1NywgMTU4LCAxNTgpIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZGRkIiBzdHlsZT0ib3BhY2l0eTowLjA3MjtzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgLTEzNSkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMDcyO3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCA0MDUpIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjEzMjY2NjY2NjY2NjY3O3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCAtMTIwKSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzIyMiIgc3R5bGU9Im9wYWNpdHk6MC4xMzI2NjY2NjY2NjY2NztzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgNDIwKSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzIyMiIgc3R5bGU9Im9wYWNpdHk6MC4wODA2NjY2NjY2NjY2Njc7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIC0xMDUpIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjA4MDY2NjY2NjY2NjY2NztzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgNDM1KSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzIyMiIgc3R5bGU9Im9wYWNpdHk6MC4xNTtzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgLTkwKSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzIyMiIgc3R5bGU9Im9wYWNpdHk6MC4xNTtzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgNDUwKSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2RkZCIgc3R5bGU9Im9wYWNpdHk6MC4wNTQ2NjY2NjY2NjY2Njc7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIC03NSkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMDU0NjY2NjY2NjY2NjY3O3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCA0NjUpIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjA0NjtzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgLTYwKSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzIyMiIgc3R5bGU9Im9wYWNpdHk6MC4wNDY7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDQ4MCkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMTU7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIC00NSkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMTU7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDQ5NSkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMTU7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIC0zMCkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMTU7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDUxMCkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMDU0NjY2NjY2NjY2NjY3O3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCAtMTUpIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZGRkIiBzdHlsZT0ib3BhY2l0eTowLjA1NDY2NjY2NjY2NjY2NztzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgNTI1KSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2RkZCIgc3R5bGU9Im9wYWNpdHk6MC4wNTQ2NjY2NjY2NjY2Njc7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDApIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZGRkIiBzdHlsZT0ib3BhY2l0eTowLjA1NDY2NjY2NjY2NjY2NztzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgNTQwKSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzIyMiIgc3R5bGU9Im9wYWNpdHk6MC4wOTg7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDE1KSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzIyMiIgc3R5bGU9Im9wYWNpdHk6MC4wOTg7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDU1NSkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMDk4O3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCAzMCkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMDk4O3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCA1NzApIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZGRkIiBzdHlsZT0ib3BhY2l0eTowLjAzNzMzMzMzMzMzMzMzMztzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgNDUpIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZGRkIiBzdHlsZT0ib3BhY2l0eTowLjAzNzMzMzMzMzMzMzMzMztzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgNTg1KSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2RkZCIgc3R5bGU9Im9wYWNpdHk6MC4wODkzMzMzMzMzMzMzMzM7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDYwKSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2RkZCIgc3R5bGU9Im9wYWNpdHk6MC4wODkzMzMzMzMzMzMzMzM7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDYwMCkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMTU7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDc1KSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzIyMiIgc3R5bGU9Im9wYWNpdHk6MC4xNTtzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgNjE1KSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzIyMiIgc3R5bGU9Im9wYWNpdHk6MC4xNTtzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgOTApIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjE1O3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCA2MzApIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjEzMjY2NjY2NjY2NjY3O3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCAxMDUpIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjEzMjY2NjY2NjY2NjY3O3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCA2NDUpIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjA5ODtzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgMTIwKSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzIyMiIgc3R5bGU9Im9wYWNpdHk6MC4wOTg7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDY2MCkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMDcyO3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCAxMzUpIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZGRkIiBzdHlsZT0ib3BhY2l0eTowLjA3MjtzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgNjc1KSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2RkZCIgc3R5bGU9Im9wYWNpdHk6MC4xMjQ7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDE1MCkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMTI0O3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCA2OTApIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZGRkIiBzdHlsZT0ib3BhY2l0eTowLjA1NDY2NjY2NjY2NjY2NztzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgMTY1KSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2RkZCIgc3R5bGU9Im9wYWNpdHk6MC4wNTQ2NjY2NjY2NjY2Njc7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDcwNSkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMTA2NjY2NjY2NjY2Njc7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDE4MCkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMTA2NjY2NjY2NjY2Njc7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDcyMCkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMTMyNjY2NjY2NjY2Njc7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDE5NSkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMTMyNjY2NjY2NjY2Njc7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDczNSkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMDgwNjY2NjY2NjY2NjY3O3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCAyMTApIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjA4MDY2NjY2NjY2NjY2NztzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgNzUwKSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzIyMiIgc3R5bGU9Im9wYWNpdHk6MC4wOTg7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDIyNSkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMDk4O3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCA3NjUpIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjEzMjY2NjY2NjY2NjY3O3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCAyNDApIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjEzMjY2NjY2NjY2NjY3O3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCA3ODApIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjA2MzMzMzMzMzMzMzMzMztzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgMjU1KSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzIyMiIgc3R5bGU9Im9wYWNpdHk6MC4wNjMzMzMzMzMzMzMzMzM7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDc5NSkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMTE1MzMzMzMzMzMzMzM7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDI3MCkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMTE1MzMzMzMzMzMzMzM7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDgxMCkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMTMyNjY2NjY2NjY2Njc7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDI4NSkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMTMyNjY2NjY2NjY2Njc7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDgyNSkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMDYzMzMzMzMzMzMzMzMzO3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCAzMDApIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjA2MzMzMzMzMzMzMzMzMztzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgODQwKSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2RkZCIgc3R5bGU9Im9wYWNpdHk6MC4wMzczMzMzMzMzMzMzMzM7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDMxNSkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMDM3MzMzMzMzMzMzMzMzO3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCA4NTUpIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjE1O3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCAzMzApIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjE1O3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCA4NzApIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjEzMjY2NjY2NjY2NjY3O3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCAzNDUpIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjEzMjY2NjY2NjY2NjY3O3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCA4ODUpIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZGRkIiBzdHlsZT0ib3BhY2l0eTowLjAzNzMzMzMzMzMzMzMzMztzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgMzYwKSIgLz48cGF0aCBkPSJNMCA5MCBDIDM4LjUgMCwgNzIgMCwgMTEwIDkwIFMgMTgyIDE4MCwgMjIwIDkwIFMgMjkyIDAsIDMzMCwgOTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2RkZCIgc3R5bGU9Im9wYWNpdHk6MC4wMzczMzMzMzMzMzMzMzM7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDkwMCkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMTQxMzMzMzMzMzMzMzM7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDM3NSkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiNkZGQiIHN0eWxlPSJvcGFjaXR5OjAuMTQxMzMzMzMzMzMzMzM7c3Ryb2tlLXdpZHRoOjE1cHg7IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNTUsIDkxNSkiIC8+PHBhdGggZD0iTTAgOTAgQyAzOC41IDAsIDcyIDAsIDExMCA5MCBTIDE4MiAxODAsIDIyMCA5MCBTIDI5MiAwLCAzMzAsIDkwIiBmaWxsPSJub25lIiBzdHJva2U9IiMyMjIiIHN0eWxlPSJvcGFjaXR5OjAuMDYzMzMzMzMzMzMzMzMzO3N0cm9rZS13aWR0aDoxNXB4OyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTU1LCAzOTApIiAvPjxwYXRoIGQ9Ik0wIDkwIEMgMzguNSAwLCA3MiAwLCAxMTAgOTAgUyAxODIgMTgwLCAyMjAgOTAgUyAyOTIgMCwgMzMwLCA5MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjIyIiBzdHlsZT0ib3BhY2l0eTowLjA2MzMzMzMzMzMzMzMzMztzdHJva2Utd2lkdGg6MTVweDsiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01NSwgOTMwKSIgLz48L3N2Zz4=";}}', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(156, 'sparkling', 'a:2:{s:12:"nav_bg_color";s:7:"#ffffff";s:14:"nav_link_color";s:7:"#0a0808";}', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE IF NOT EXISTS `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=119 ;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 4, '_wp_attached_file', '2017/10/laa-logo-1.png'),
(3, 4, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:155;s:6:"height";i:76;s:4:"file";s:22:"2017/10/laa-logo-1.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"laa-logo-1-150x76.png";s:5:"width";i:150;s:6:"height";i:76;s:9:"mime-type";s:9:"image/png";}s:9:"tab-small";a:4:{s:4:"file";s:20:"laa-logo-1-60x60.png";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(4, 5, '_wp_attached_file', '2017/10/cropped-laa-logo-1.png'),
(5, 5, '_wp_attachment_context', 'custom-header'),
(6, 5, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:155;s:6:"height";i:75;s:4:"file";s:30:"2017/10/cropped-laa-logo-1.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"cropped-laa-logo-1-150x75.png";s:5:"width";i:150;s:6:"height";i:75;s:9:"mime-type";s:9:"image/png";}s:9:"tab-small";a:4:{s:4:"file";s:28:"cropped-laa-logo-1-60x60.png";s:5:"width";i:60;s:6:"height";i:60;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(7, 5, '_wp_attachment_custom_header_last_used_sparkling.2.3.5/sparkling', '1508150014'),
(8, 5, '_wp_attachment_is_custom_header', 'sparkling.2.3.5/sparkling'),
(9, 6, '_wp_trash_meta_status', 'publish'),
(10, 6, '_wp_trash_meta_time', '1508150015'),
(11, 7, '_edit_last', '1'),
(12, 7, '_wp_page_template', 'default'),
(13, 7, '_edit_lock', '1508149986:1'),
(14, 9, '_edit_last', '1'),
(15, 9, '_wp_page_template', 'default'),
(16, 9, '_edit_lock', '1508150024:1'),
(35, 13, '_edit_last', '1'),
(36, 13, '_wp_page_template', 'default'),
(37, 13, '_edit_lock', '1508150283:1'),
(38, 15, '_edit_last', '1'),
(39, 15, '_edit_lock', '1508150305:1'),
(40, 15, '_wp_page_template', 'default'),
(41, 17, '_edit_last', '1'),
(42, 17, '_edit_lock', '1508150328:1'),
(43, 17, '_wp_page_template', 'default'),
(44, 19, '_edit_last', '1'),
(45, 19, '_edit_lock', '1508150365:1'),
(46, 19, '_wp_page_template', 'default'),
(47, 21, '_edit_last', '1'),
(48, 21, '_wp_page_template', 'default'),
(49, 21, '_edit_lock', '1508150387:1'),
(95, 28, '_menu_item_type', 'custom'),
(96, 28, '_menu_item_menu_item_parent', '0'),
(97, 28, '_menu_item_object_id', '28'),
(98, 28, '_menu_item_object', 'custom'),
(99, 28, '_menu_item_target', ''),
(100, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(101, 28, '_menu_item_xfn', ''),
(102, 28, '_menu_item_url', 'http://www.laaproperties.com/'),
(103, 28, '_menu_item_orphaned', '1508150814'),
(104, 29, '_menu_item_type', 'custom'),
(105, 29, '_menu_item_menu_item_parent', '0'),
(106, 29, '_menu_item_object_id', '29'),
(107, 29, '_menu_item_object', 'custom'),
(108, 29, '_menu_item_target', ''),
(109, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(110, 29, '_menu_item_xfn', ''),
(111, 29, '_menu_item_url', 'http://www.laaproperties.com/'),
(113, 30, '_edit_last', '1'),
(114, 30, '_edit_lock', '1508150924:1'),
(117, 32, '_wp_trash_meta_status', 'publish'),
(118, 32, '_wp_trash_meta_time', '1508154382');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE IF NOT EXISTS `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=33 ;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2017-10-16 10:28:27', '2017-10-16 10:28:27', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2017-10-16 10:28:27', '2017-10-16 10:28:27', '', 0, 'http://localhost:8080/blog/?p=1', 0, 'post', '', 1),
(2, 1, '2017-10-16 10:28:27', '2017-10-16 10:28:27', 'This is an example page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin'' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://localhost:8080/blog/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2017-10-16 10:28:27', '2017-10-16 10:28:27', '', 0, 'http://localhost:8080/blog/?page_id=2', 0, 'page', '', 0),
(3, 1, '2017-10-16 10:28:56', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-10-16 10:28:56', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/blog/?p=3', 0, 'post', '', 0),
(4, 1, '2017-10-16 10:32:53', '2017-10-16 10:32:53', '', 'laa-logo-1', '', 'inherit', 'open', 'closed', '', 'laa-logo-1', '', '', '2017-10-16 10:32:53', '2017-10-16 10:32:53', '', 0, 'http://localhost:8080/blog/wp-content/uploads/2017/10/laa-logo-1.png', 0, 'attachment', 'image/png', 0),
(5, 1, '2017-10-16 10:33:04', '2017-10-16 10:33:04', '', 'cropped-laa-logo-1.png', '', 'inherit', 'open', 'closed', '', 'cropped-laa-logo-1-png', '', '', '2017-10-16 10:33:04', '2017-10-16 10:33:04', '', 0, 'http://localhost:8080/blog/wp-content/uploads/2017/10/cropped-laa-logo-1.png', 0, 'attachment', 'image/png', 0),
(6, 1, '2017-10-16 10:33:34', '2017-10-16 10:33:34', '{\n    "sparkling.2.3.5/sparkling::header_image": {\n        "value": "http://localhost:8080/blog/wp-content/uploads/2017/10/cropped-laa-logo-1.png",\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "sparkling.2.3.5/sparkling::header_image_data": {\n        "value": {\n            "url": "http://localhost:8080/blog/wp-content/uploads/2017/10/cropped-laa-logo-1.png",\n            "thumbnail_url": "http://localhost:8080/blog/wp-content/uploads/2017/10/cropped-laa-logo-1.png",\n            "timestamp": 1508149985315,\n            "attachment_id": 5,\n            "width": 155,\n            "height": 75\n        },\n        "type": "theme_mod",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '75abd3d2-1186-487e-a3d9-b762014f090d', '', '', '2017-10-16 10:33:34', '2017-10-16 10:33:34', '', 0, 'http://localhost:8080/blog/?p=6', 0, 'customize_changeset', '', 0),
(7, 1, '2017-10-16 10:35:13', '2017-10-16 10:35:13', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2017-10-16 10:35:13', '2017-10-16 10:35:13', '', 0, 'http://localhost:8080/blog/?page_id=7', 0, 'page', '', 0),
(8, 1, '2017-10-16 10:35:13', '2017-10-16 10:35:13', '', 'Home', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2017-10-16 10:35:13', '2017-10-16 10:35:13', '', 7, 'http://localhost:8080/blog/index.php/2017/10/16/7-revision-v1/', 0, 'revision', '', 0),
(9, 1, '2017-10-16 10:35:41', '2017-10-16 10:35:41', '', 'Contact us', '', 'publish', 'closed', 'closed', '', 'contact-us', '', '', '2017-10-16 10:35:41', '2017-10-16 10:35:41', '', 0, 'http://localhost:8080/blog/?page_id=9', 0, 'page', '', 0),
(10, 1, '2017-10-16 10:35:41', '2017-10-16 10:35:41', '', 'Contact us', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2017-10-16 10:35:41', '2017-10-16 10:35:41', '', 9, 'http://localhost:8080/blog/index.php/2017/10/16/9-revision-v1/', 0, 'revision', '', 0),
(13, 1, '2017-10-16 10:40:13', '2017-10-16 10:40:13', '', 'ABOUT', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2017-10-16 10:40:13', '2017-10-16 10:40:13', '', 0, 'http://localhost:8080/blog/?page_id=13', 0, 'page', '', 0),
(14, 1, '2017-10-16 10:40:13', '2017-10-16 10:40:13', '', 'ABOUT', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2017-10-16 10:40:13', '2017-10-16 10:40:13', '', 13, 'http://localhost:8080/blog/index.php/2017/10/16/13-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2017-10-16 10:40:37', '2017-10-16 10:40:37', '', 'PROJECTS', '', 'publish', 'closed', 'closed', '', 'projects', '', '', '2017-10-16 10:40:37', '2017-10-16 10:40:37', '', 0, 'http://localhost:8080/blog/?page_id=15', 0, 'page', '', 0),
(16, 1, '2017-10-16 10:40:37', '2017-10-16 10:40:37', '', 'PROJECTS', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2017-10-16 10:40:37', '2017-10-16 10:40:37', '', 15, 'http://localhost:8080/blog/index.php/2017/10/16/15-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2017-10-16 10:40:59', '2017-10-16 10:40:59', '', 'GALLERY', '', 'publish', 'closed', 'closed', '', 'gallery', '', '', '2017-10-16 10:40:59', '2017-10-16 10:40:59', '', 0, 'http://localhost:8080/blog/?page_id=17', 0, 'page', '', 0),
(18, 1, '2017-10-16 10:40:59', '2017-10-16 10:40:59', '', 'GALLERY', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2017-10-16 10:40:59', '2017-10-16 10:40:59', '', 17, 'http://localhost:8080/blog/index.php/2017/10/16/17-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2017-10-16 10:41:28', '2017-10-16 10:41:28', '', 'INTERIOR', '', 'publish', 'closed', 'closed', '', 'interior', '', '', '2017-10-16 10:41:28', '2017-10-16 10:41:28', '', 0, 'http://localhost:8080/blog/?page_id=19', 0, 'page', '', 0),
(20, 1, '2017-10-16 10:41:28', '2017-10-16 10:41:28', '', 'INTERIOR', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2017-10-16 10:41:28', '2017-10-16 10:41:28', '', 19, 'http://localhost:8080/blog/index.php/2017/10/16/19-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2017-10-16 10:41:55', '2017-10-16 10:41:55', '', 'BLOG', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2017-10-16 10:41:55', '2017-10-16 10:41:55', '', 0, 'http://localhost:8080/blog/?page_id=21', 0, 'page', '', 0),
(22, 1, '2017-10-16 10:41:55', '2017-10-16 10:41:55', '', 'BLOG', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2017-10-16 10:41:55', '2017-10-16 10:41:55', '', 21, 'http://localhost:8080/blog/index.php/2017/10/16/21-revision-v1/', 0, 'revision', '', 0),
(28, 1, '2017-10-16 10:46:53', '0000-00-00 00:00:00', '', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-10-16 10:46:53', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/blog/?p=28', 1, 'nav_menu_item', '', 0),
(29, 1, '2017-10-16 10:48:50', '2017-10-16 10:48:50', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2017-10-16 10:48:50', '2017-10-16 10:48:50', '', 0, 'http://localhost:8080/blog/?p=29', 1, 'nav_menu_item', '', 0),
(30, 1, '2017-10-16 10:50:26', '2017-10-16 10:50:26', 'Sparkling is a clean minimal and responsive WordPress theme well suited for travel, health, business, finance, portfolio, design, art, photography, personal, ecommerce and any other creative websites and blogs. Developed using Bootstrap 3 that makes it mobile and tablets friendly. \r\nTheme comes with full-screen slider, social icon integration, author bio, popular posts widget and improved category widget. Sparkling incorporates latest web standards such as HTML5 and CSS3 and is SEO friendly thanks to its clean structure and codebase. \r\nIt has dozens of Theme Options based on WordPress Customizer to change theme layout, colors, fonts, slider settings and much more. Theme is also translation and multilingual ready, compatible with WPML and is available in Spanish, French, Dutch, Polish, Russian, German, Brazilian Portuguese, Portuguese (Portugal), Persian (Iranian language), Romanian, Turkish, Bulgarian, Japanese, Lithuanian, Czech, Ukrainian, Traditional Chinese, Simplified Chinese, Indonesian, Estonian, Spanish (Argentina), Hungarian and Italian. Sparkling is a free WordPress theme with premium functionality and design. Theme is ecommerce ready thanks to its WooCommerce integration. Now theme is optimized to work with bbPress, Contact Form 7, Jetpack, WooCommerce and other popular free and premium plugins.\r\n Lately we introduced a sticky/fixed navigation that you can enable or disable via WordPress Customizer.', '1ST BLOG', '', 'publish', 'open', 'open', '', '1st-blog', '', '', '2017-10-16 10:50:26', '2017-10-16 10:50:26', '', 0, 'http://localhost:8080/blog/?p=30', 0, 'post', '', 0),
(31, 1, '2017-10-16 10:50:26', '2017-10-16 10:50:26', 'Sparkling is a clean minimal and responsive WordPress theme well suited for travel, health, business, finance, portfolio, design, art, photography, personal, ecommerce and any other creative websites and blogs. Developed using Bootstrap 3 that makes it mobile and tablets friendly. \r\nTheme comes with full-screen slider, social icon integration, author bio, popular posts widget and improved category widget. Sparkling incorporates latest web standards such as HTML5 and CSS3 and is SEO friendly thanks to its clean structure and codebase. \r\nIt has dozens of Theme Options based on WordPress Customizer to change theme layout, colors, fonts, slider settings and much more. Theme is also translation and multilingual ready, compatible with WPML and is available in Spanish, French, Dutch, Polish, Russian, German, Brazilian Portuguese, Portuguese (Portugal), Persian (Iranian language), Romanian, Turkish, Bulgarian, Japanese, Lithuanian, Czech, Ukrainian, Traditional Chinese, Simplified Chinese, Indonesian, Estonian, Spanish (Argentina), Hungarian and Italian. Sparkling is a free WordPress theme with premium functionality and design. Theme is ecommerce ready thanks to its WooCommerce integration. Now theme is optimized to work with bbPress, Contact Form 7, Jetpack, WooCommerce and other popular free and premium plugins.\r\n Lately we introduced a sticky/fixed navigation that you can enable or disable via WordPress Customizer.', '1ST BLOG', '', 'inherit', 'closed', 'closed', '', '30-revision-v1', '', '', '2017-10-16 10:50:26', '2017-10-16 10:50:26', '', 30, 'http://localhost:8080/blog/index.php/2017/10/16/30-revision-v1/', 0, 'revision', '', 0),
(32, 1, '2017-10-16 11:46:21', '2017-10-16 11:46:21', '{\n    "sparkling[nav_bg_color]": {\n        "value": "#ffffff",\n        "type": "option",\n        "user_id": 1\n    },\n    "sparkling[nav_link_color]": {\n        "value": "#0a0808",\n        "type": "option",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '90b8ebbd-f6b1-48b3-b853-41f9e6009869', '', '', '2017-10-16 11:46:21', '2017-10-16 11:46:21', '', 0, 'http://localhost:8080/blog/index.php/2017/10/16/90b8ebbd-f6b1-48b3-b853-41f9e6009869/', 0, 'customize_changeset', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE IF NOT EXISTS `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'main navigation', 'main-navigation', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE IF NOT EXISTS `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(29, 2, 0),
(30, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE IF NOT EXISTS `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 2),
(2, 2, 'nav_menu', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE IF NOT EXISTS `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=22 ;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'locale', ''),
(11, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(12, 1, 'wp_user_level', '10'),
(13, 1, 'dismissed_wp_pointers', ''),
(14, 1, 'show_welcome_panel', '1'),
(15, 1, 'session_tokens', 'a:1:{s:64:"693d9ae8f9f56e76b82b09979284a1bf9b6a902dd3c9d87368eaa1a321f3bd9e";a:4:{s:10:"expiration";i:1508322532;s:2:"ip";s:3:"::1";s:2:"ua";s:102:"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36";s:5:"login";i:1508149732;}}'),
(16, 1, 'wp_dashboard_quick_press_last_post_id', '3'),
(17, 1, 'wp_user-settings', 'libraryContent=browse&editor=html'),
(18, 1, 'wp_user-settings-time', '1508151026'),
(19, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(20, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:12:"add-post_tag";i:1;s:15:"add-post_format";}'),
(21, 1, 'nav_menu_recently_edited', '2');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BGKUpf8KXwgzS/4EyU3hT2QJ.y4rUL0', 'admin', 'admin@gmail.com', '', '2017-10-16 10:28:26', '', 0, 'admin');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
